
# Calorie Tracker (PWA)

Dark + neon themed **offline** food & steps tracker.

## Deploy on GitHub Pages
1. Upload **all files in this folder** to your repo root: https://github.com/chrislawler87-cyber/food-steps-tracker
2. Settings → Pages → Source: `main` and Folder: `/ (root)` → Save
3. Open: https://chrislawler87-cyber.github.io/food-steps-tracker/
4. In Chrome on your phone: ⋮ → Add to Home screen

