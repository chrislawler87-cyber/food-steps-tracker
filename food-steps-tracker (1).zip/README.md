
# Calorie Tracker (Food & Steps Tracker)

Dark + neon themed PWA to track food, calories, macros, and steps offline.

## 📱 Quick Upload (GitHub Pages)

1. Go to your GitHub repo: https://github.com/chrislawler87-cyber/food-steps-tracker  
2. Click **Add file → Upload files**  
3. Upload this ZIP file (`food-steps-tracker.zip`) — GitHub will unpack it automatically.  
4. Click **Commit changes**.  
5. Go to **Settings → Pages** → Source: `main`, Folder: `/ (root)` → Save.  
6. Wait 1–2 minutes, then open:  
   https://chrislawler87-cyber.github.io/food-steps-tracker/  
7. In Chrome → tap ⋮ → **Add to Home screen** → Add.  

You’re good to go — offline calorie tracking, saved meals, and barcode lookup ready!
